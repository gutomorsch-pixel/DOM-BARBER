export const business = { name: 'PetDoJeff', whatsapp: '', email: '', address: '' };
export const services = [
  { title: 'Banho & tosa', description: 'Carinho em cada etapa, do banho à finalização. Um cuidado que respeita o jeitinho do seu pet.', icon: 'bath', tag: 'Cuidado que faz bem' },
  { title: 'Tudo para seu pet', description: 'Alimentação, acessórios e brinquedos escolhidos para uma vida mais saudável e divertida.', icon: 'bag', tag: 'Escolhas com carinho' },
  { title: 'Bem-estar animal', description: 'Atenção aos detalhes e orientação para tornar a rotina do seu melhor amigo ainda melhor.', icon: 'heart', tag: 'Mais qualidade de vida' },
];
export const faqs = [
  ['Como posso agendar um banho e tosa?', 'Entre em contato para informar a raça, o porte e as necessidades do seu pet. Assim, podemos orientar sobre o cuidado ideal e consultar a disponibilidade.'],
  ['O atendimento é personalizado para cada pet?', 'A proposta da PetDoJeff é respeitar o porte, a pelagem e o temperamento de cada animal. Informe alergias, sensibilidades ou recomendações veterinárias antes do atendimento.'],
  ['Quais produtos posso encontrar?', 'Nossa seleção proposta inclui alimentação, acessórios, brinquedos e itens de higiene. Consulte a equipe para confirmar os produtos e a disponibilidade.'],
  ['Vocês cuidam de cães e gatos?', 'Consulte a equipe sobre os serviços disponíveis para a espécie, o porte e o perfil do seu pet.'],
  ['Como saber o valor do serviço?', 'O orçamento depende do porte, da pelagem e do cuidado escolhido. Fale com a equipe para receber uma orientação personalizada.'],
];
export function pageHead(title: string, description: string) {
  return { meta: [{ title: `${title} | PetDoJeff` }, { name: 'description', content: description }, { property: 'og:title', content: `${title} | PetDoJeff` }, { property: 'og:description', content: description }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' }] };
}