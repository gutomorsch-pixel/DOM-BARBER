import { createFileRoute } from '@tanstack/react-router';
import { ReviewsSection, PageBanner } from '@/components/pet-site';
import { pageHead } from '@/lib/site';
export const Route = createFileRoute('/depoimentos')({ head: () => pageHead('Depoimentos', 'Um espaço para as histórias de cuidado e confiança dos clientes da PetDoJeff. Relatos reais em breve.'), component: Page });
function Page() { return <><PageBanner label="Histórias de carinho" title="A confiança é o nosso melhor presente." text="Este espaço está reservado para quem vive o cuidado PetDoJeff. Depoimentos reais serão publicados após confirmação." /><ReviewsSection /></>; }