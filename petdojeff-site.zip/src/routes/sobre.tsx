import { createFileRoute } from '@tanstack/react-router';
import { AboutSection, PageBanner } from '@/components/pet-site';
import { pageHead } from '@/lib/site';
export const Route = createFileRoute('/sobre')({ head: () => pageHead('Nossa essência', 'Conheça a essência da PetDoJeff e nossa proposta de acolhimento, respeito e carinho para cada pet.'), component: Page });
function Page() { return <><PageBanner label="Nossa essência" title="Um petshop com coração." text="Acreditamos que cuidar de um pet é cuidar de uma parte muito especial da sua família." /><AboutSection /></>; }