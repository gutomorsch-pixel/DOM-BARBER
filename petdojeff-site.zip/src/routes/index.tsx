import { createFileRoute } from '@tanstack/react-router';
import { HomeHero, ServicesSection, AboutSection, GallerySection, ReviewsSection, FaqSection } from '@/components/pet-site';
import { pageHead } from '@/lib/site';
export const Route = createFileRoute('/')({ head: () => pageHead('Petshop, banho e tosa com carinho', 'Conheça a PetDoJeff: uma proposta de cuidado personalizado, banho e tosa, produtos e bem-estar para o seu melhor amigo.'), component: Index });
function Index() { return <><HomeHero /><ServicesSection /><AboutSection /><GallerySection /><ReviewsSection /><FaqSection /></>; }
