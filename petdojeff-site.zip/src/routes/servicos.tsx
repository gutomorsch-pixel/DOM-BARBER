import { createFileRoute } from '@tanstack/react-router';
import { ServicesSection, PageBanner } from '@/components/pet-site';
import { pageHead } from '@/lib/site';
export const Route = createFileRoute('/servicos')({ head: () => pageHead('Serviços e cuidados', 'Explore a proposta de banho e tosa, produtos e bem-estar da PetDoJeff. Consulte serviços e disponibilidade.'), component: Page });
function Page() { return <><PageBanner label="Nossos cuidados" title="Para cada patinha, um cuidado." text="Conheça nossa proposta de serviços e encontre o que combina com o jeitinho do seu melhor amigo." /><ServicesSection /></>; }