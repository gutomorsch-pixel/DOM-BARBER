import { createFileRoute } from '@tanstack/react-router';
import { GallerySection, PageBanner } from '@/components/pet-site';
import { pageHead } from '@/lib/site';
export const Route = createFileRoute('/galeria')({ head: () => pageHead('Galeria de pets', 'Inspire-se com a galeria ilustrativa da PetDoJeff: carinho, banho e momentos de bem-estar.'), component: Page });
function Page() { return <><PageBanner label="Nosso universo" title="Cada patinha, uma história de amor." text="Momentos que traduzem o cuidado e o carinho que queremos compartilhar com você." /><GallerySection /></>; }