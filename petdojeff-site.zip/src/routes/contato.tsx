import { createFileRoute } from '@tanstack/react-router';
import { ContactPage } from '@/components/pet-site';
import { pageHead } from '@/lib/site';
export const Route = createFileRoute('/contato')({ head: () => pageHead('Contato e agendamento', 'Converse com a PetDoJeff sobre seu pet, serviços e cuidados. Canais de atendimento e localização em preparação.'), component: ContactPage });