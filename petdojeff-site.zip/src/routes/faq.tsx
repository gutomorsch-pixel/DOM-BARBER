import { createFileRoute } from '@tanstack/react-router';
import { FaqSection, PageBanner } from '@/components/pet-site';
import { pageHead } from '@/lib/site';
export const Route = createFileRoute('/faq')({ head: () => pageHead('Perguntas frequentes', 'Tire suas dúvidas sobre agendamentos, cuidados personalizados e a proposta de serviços da PetDoJeff.'), component: Page });
function Page() { return <><PageBanner label="Perguntas frequentes" title="Uma boa conversa faz diferença." text="Encontre respostas para as dúvidas mais comuns sobre os cuidados com seu melhor amigo." /><FaqSection /></>; }