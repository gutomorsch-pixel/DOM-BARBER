# PetDoJeff
- [x] Criar identidade visual, página inicial e páginas de serviços, sobre, galeria, depoimentos, dúvidas e contato.
- [x] Verificar navegação, formulário e apresentação em telas grandes e pequenas.
- [x] Remover formulário e manter contato por telefone, sem login ou armazenamento de visitantes.
- [ ] Exibir telefone real: aguarda número com DDD da empresa.