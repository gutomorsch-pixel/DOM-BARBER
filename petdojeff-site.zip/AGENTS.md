<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Public pages share a single SiteShell in the root route; route-specific metadata stays in each leaf to keep navigation and SEO consistent.
- Business contact details live in src/lib/site.ts; never invent phone numbers or addresses, and keep contact actions explicit when details are missing.
- Contact is a static telephone-only view with no visitor submission or persistence, keeping the site independent of a database.
- Generated pet images are illustrative; gallery and testimonial drafts must not be represented as verified customer evidence.
